package fi.helsinki.cs.reittiopas;

import fi.helsinki.cs.reittiopas.logic.Stop;
import fi.helsinki.cs.reittiopas.logic.State;
import java.util.Comparator;

public class StateComparator implements Comparator<State> {

    private final Stop goal;

    public StateComparator(Stop goalStop) {
        this.goal = goalStop;
    }

    /**
     * Implement this
     *
     * @param stop
     * @return Estimated remaining time
     */
    public double heuristic(Stop stop) {
                return Math.sqrt((stop.getX() - goal.getX()) * (stop.getX() - goal.getX())
                + (stop.getY() - goal.getY()) * (stop.getY() - goal.getY())) / 260.0;
    }

    /**
     * Implement this
     *
     * @param t1
     * @param t2
     * @return result of the comparison
     */
    @Override
    public int compare(State t1, State t2) {
        if (t1.getCurrentTime()+ heuristic(t1.getStop()) > t2.getCurrentTime()+ heuristic(t2.getStop())) {
            return 1;
        }
        if (t1.getCurrentTime()+ heuristic(t1.getStop()) < t2.getCurrentTime()+ heuristic(t2.getStop())) {
            return -1;
        }
        return 0;
    }

}
