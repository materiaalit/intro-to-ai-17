package fi.helsinki.cs.reittiopas;

import fi.helsinki.cs.reittiopas.logic.Stop;
import fi.helsinki.cs.reittiopas.logic.State;
import java.util.HashMap;
import java.util.Map;

import java.util.PriorityQueue;

public class TravelPlanner {

    private StateComparator stateComparator;

    /**
     * Implement A*
     *
     */
    public State search(Stop start, Stop goal, int timeAtBeginning) {
        PriorityQueue<State> examinees = new PriorityQueue<>(new StateComparator(goal));
        examinees.add(new State(start, null, timeAtBeginning));
        
        State state;
        Map<Stop, Integer> bestTime = new HashMap<>();
        bestTime.put(start, 0);

        while (!examinees.isEmpty()) {
            state = examinees.poll();

            if (state.getStop().equals(goal)) {
                return state;
            }

            for (Stop s : state.getStop().getNeighbors()) {
                int time = state.getCurrentTime() + state.getStop().fastestTransition(s, state.getCurrentTime());

                if (bestTime.containsKey(s) && bestTime.get(s) <= time) {
                    continue;
                }
                bestTime.put(s, time);
                examinees.add(new State(s, state, time));
            }
        }
        return null;
    }
}
