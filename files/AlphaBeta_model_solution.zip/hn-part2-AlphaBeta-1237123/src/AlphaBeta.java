public class AlphaBeta {
    public static int alphaBetaValue(AlphaBetaNode node) {
        if (node.isMaxNode()) {
            return maxValue(node, -1, 1);
        } else {
            return minValue(node, -1, 1);
        }
    }

    private static int maxValue(AlphaBetaNode node, int alpha, int beta) {
        if (node.isEndState()) {
            return node.value();
        }
        int value = Integer.MIN_VALUE;
        for (AlphaBetaNode child : node.generateChildren()) {
            value = Math.max(value, minValue(child, alpha, beta));
            if (value >= beta) {
                return value;
            }
            alpha = Math.max(alpha, value);
        }
        return value;
    }

    private static int minValue(AlphaBetaNode node, int alpha, int beta) {
        if (node.isEndState()) {
            return node.value();
        }
        int value = Integer.MAX_VALUE;
        for (AlphaBetaNode child : node.generateChildren()) {
            value = Math.min(value, maxValue(child, alpha, beta));
            if (value <= alpha) {
                return value;
            }
            beta = Math.min(beta, value);
        }
        return value;
    }
}
