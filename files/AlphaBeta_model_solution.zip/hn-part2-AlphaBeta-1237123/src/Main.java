
import java.util.List;

public class Main {

    public static void main(String[] args) {
        String emptyBoard = "???" + "???" + "???";
        TicTacToe r = new TicTacToe(emptyBoard, true);
        System.out.println(r);
        play(r);
    }

    private static void play(TicTacToe r) {
         while (!r.isEndState()) {
            if (r.crossesTurn) {
                int value = -1;
                List<AlphaBetaNode> lapset = r.generateChildren();
                r = (TicTacToe) lapset.get(0);
                for (AlphaBetaNode l : lapset) {
                    int eval = AlphaBeta.alphaBetaValue(l);
                    if (eval > value) {
                        value = eval;
                        r = (TicTacToe) l;
                    }
                }
                System.out.println(r);
            } else {
                int value = 1;
                List<AlphaBetaNode> lapset = r.generateChildren();
                r = (TicTacToe) lapset.get(0);
                for (AlphaBetaNode l : lapset) {
                    int eval = AlphaBeta.alphaBetaValue(l);
                    if (eval < value) {
                        value = eval;
                        r = (TicTacToe) l;
                    }
                }
                System.out.println(r);
            }
         }
    }
}
