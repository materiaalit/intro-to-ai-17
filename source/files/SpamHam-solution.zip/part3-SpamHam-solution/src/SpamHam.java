import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class SpamHam {
    private final static String SPAM_PATH = "spamcount.txt";
    private final static String HAM_PATH  = "hamcount.txt";
    private final static String MESSAGE_PATH = "hamexample.txt";

    private static List<String> readMessage(String file) throws IOException {
        String text = new String(Files.readAllBytes(Paths.get(file)));
        return Arrays.asList(text.split("\\s+"));
    }

    private static Map<String, Integer> readOccurences(String file)
            throws FileNotFoundException {
        Map<String, Integer> counts;
        try (Scanner sc = new Scanner(new File(file))) {
            counts = new HashMap<>();
            while (sc.hasNext()) {
                int occurences = sc.nextInt();
                String word = sc.next();
                counts.put(word, occurences);
            }
        }

        return counts;
    }

    public static void main(String[] args) throws FileNotFoundException, IOException {
        Map<String, Integer> spam = readOccurences(SPAM_PATH);
        Map<String, Integer> ham = readOccurences(HAM_PATH);
        List<String> words = readMessage(MESSAGE_PATH);
        
        double spamSum = spam.values().stream().mapToInt(Number::intValue).sum();
        double hamSum  = ham.values().stream().mapToInt(Number::intValue).sum();
    
        double odds = 0.0; // P(spam) = 0.5 => log(0.5 / 0.5) = 0
        for (String word : words) {
            int spamFreq = spam.getOrDefault(word, 0);
            int hamFreq = ham.getOrDefault(word, 0);
            odds += Math.log(spamFreq == 0 ? 0.00001 : spamFreq / spamSum) -
                    Math.log(hamFreq == 0 ? 0.00001 : hamFreq / hamSum);
        }

        odds = Math.exp(odds);
        System.out.println(odds / (1 + odds));
    }
}
