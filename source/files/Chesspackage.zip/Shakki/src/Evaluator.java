public abstract class Evaluator {
	public abstract double eval(Position p);
}
