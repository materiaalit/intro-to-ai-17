public class YourEvaluator extends Evaluator {

    // Implement your heuristic evaluation function here!
    // The below default function prefers:
    //  * not to lose (white king is worth at lot)
    //  * to win (black not having a king is worth a lot)
    //  * to have more white pieces (+1) and less black pieces (-1)

	public double eval(Position p) {
		double ret = 0;
		for(int x = 0; x < p.board.length; ++x) {
			for(int y = 0; y < p.board[x].length; ++y) {
				if(p.board[x][y] == Position.Empty) continue;
				if(p.board[x][y] == Position.WKing) ret += 1e9;
				if(p.board[x][y] == Position.WQueen) ret += 1;
				if(p.board[x][y] == Position.WRook) ret += 1;
				if(p.board[x][y] == Position.WBishop) ret += 1;
				if(p.board[x][y] == Position.WKnight) ret += 1;
				if(p.board[x][y] == Position.WPawn) ret += 1;
				if(p.board[x][y] == Position.BKing) ret -= 1e9;
				if(p.board[x][y] == Position.BQueen) ret -= 1;
				if(p.board[x][y] == Position.BRook) ret -= 1;
				if(p.board[x][y] == Position.BBishop) ret -= 1;
				if(p.board[x][y] == Position.BKnight) ret -= 1;
				if(p.board[x][y] == Position.BPawn) ret -= 1;
			}
		}
		return ret;
	}
}
